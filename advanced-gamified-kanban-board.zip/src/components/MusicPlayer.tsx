"use client";

import { useEffect, useRef, useState } from "react";

// Uses procedural WebAudio drones (no external files) so the "player" always works offline
type Track = { id: string; name: string; emoji: string; freqs: number[]; detune?: number };

const TRACKS: Track[] = [
  { id: "lofi", name: "Lo-fi study", emoji: "🎧", freqs: [174, 220, 261.63], detune: 4 },
  { id: "rain", name: "Rain café", emoji: "☔", freqs: [110, 165, 220] },
  { id: "space", name: "Space drift", emoji: "🛰️", freqs: [82.4, 130.81, 196] },
  { id: "forest", name: "Forest dawn", emoji: "🌲", freqs: [146.83, 220, 293.66] },
  { id: "arcade", name: "Neon arcade", emoji: "🕹️", freqs: [261.63, 329.63, 392], detune: 6 },
];

export function MusicPlayer() {
  const [open, setOpen] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [track, setTrack] = useState<Track>(TRACKS[0]);
  const [volume, setVolume] = useState(0.35);
  const ctxRef = useRef<AudioContext | null>(null);
  const nodesRef = useRef<{ osc: OscillatorNode; gain: GainNode }[]>([]);
  const masterRef = useRef<GainNode | null>(null);

  useEffect(() => {
    return () => {
      stopAudio();
      ctxRef.current?.close().catch(() => {});
    };
  }, []);

  useEffect(() => {
    if (masterRef.current && ctxRef.current) {
      masterRef.current.gain.setTargetAtTime(volume, ctxRef.current.currentTime, 0.05);
    }
  }, [volume]);

  function ensureCtx() {
    if (!ctxRef.current) {
      const AC = (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext);
      ctxRef.current = new AC();
      const master = ctxRef.current.createGain();
      master.gain.value = volume;
      master.connect(ctxRef.current.destination);
      masterRef.current = master;
    }
    return ctxRef.current;
  }

  function playAudio(t: Track) {
    stopAudio();
    const ctx = ensureCtx();
    if (ctx.state === "suspended") ctx.resume().catch(() => {});
    const nodes = t.freqs.map((f, i) => {
      const osc = ctx.createOscillator();
      osc.type = i % 2 === 0 ? "sine" : "triangle";
      osc.frequency.value = f;
      if (t.detune) osc.detune.value = (i - 1) * t.detune;
      const gain = ctx.createGain();
      gain.gain.value = 0;
      osc.connect(gain).connect(masterRef.current!);
      osc.start();
      gain.gain.setTargetAtTime(0.12, ctx.currentTime, 0.6);
      return { osc, gain };
    });
    nodesRef.current = nodes;
  }

  function stopAudio() {
    const ctx = ctxRef.current;
    nodesRef.current.forEach(({ osc, gain }) => {
      try {
        if (ctx) gain.gain.setTargetAtTime(0, ctx.currentTime, 0.1);
        setTimeout(() => { try { osc.stop(); } catch {} }, 220);
      } catch {}
    });
    nodesRef.current = [];
  }

  function toggle() {
    if (playing) { stopAudio(); setPlaying(false); }
    else { playAudio(track); setPlaying(true); }
  }
  function pickTrack(t: Track) {
    setTrack(t);
    if (playing) playAudio(t);
  }

  return (
    <div className="relative">
      <button className="btn btn-ghost !px-3" onClick={() => setOpen((v) => !v)} title="Ambient music">
        <span className={playing ? "animate-pulse" : ""}>{track.emoji}</span>
      </button>
      {open && (
        <div className="absolute right-0 top-12 glass-2 rounded-2xl p-3 w-[260px] z-50 shadow-2xl">
          <div className="flex items-center justify-between mb-2">
            <div className="font-bold text-sm">Ambient bops</div>
            <button className="text-xs opacity-70" onClick={() => setOpen(false)}>✕</button>
          </div>
          <div className="flex items-center gap-2 mb-3">
            <button className="btn btn-primary !px-3 !py-1.5 text-sm" onClick={toggle}>
              {playing ? "⏸ Pause" : "▶ Play"}
            </button>
            <div className="text-xs opacity-70 truncate">{track.name}</div>
          </div>
          <div className="grid grid-cols-5 gap-1 mb-3">
            {TRACKS.map((t) => (
              <button key={t.id} className={`glass rounded-lg py-2 text-lg ${track.id === t.id ? "ring-2" : ""}`} style={track.id === t.id ? { boxShadow: "0 0 0 2px var(--accent)" } : undefined} onClick={() => pickTrack(t)} title={t.name}>{t.emoji}</button>
            ))}
          </div>
          <label className="text-xs opacity-70">Volume</label>
          <input type="range" min={0} max={1} step={0.01} value={volume} onChange={(e) => setVolume(Number(e.target.value))} className="w-full accent-fuchsia-400" />
        </div>
      )}
    </div>
  );
}
