"use client";

import { useMemo, useState } from "react";
import { useStore } from "@/lib/store";
import { CardModal } from "./CardModal";

export function CalendarView() {
  const { board } = useStore();
  const [cursor, setCursor] = useState(() => new Date());
  const [openCardId, setOpenCardId] = useState<string | null>(null);

  const monthCells = useMemo(() => {
    const y = cursor.getFullYear();
    const m = cursor.getMonth();
    const first = new Date(y, m, 1);
    const start = new Date(first);
    start.setDate(1 - first.getDay());
    return Array.from({ length: 42 }, (_, i) => {
      const d = new Date(start);
      d.setDate(start.getDate() + i);
      return d;
    });
  }, [cursor]);

  const byDate = useMemo(() => {
    const map = new Map<string, typeof board.cards>();
    for (const c of board.cards) {
      if (!c.dueDate) continue;
      if (!map.has(c.dueDate)) map.set(c.dueDate, []);
      map.get(c.dueDate)!.push(c);
    }
    return map;
  }, [board]);

  const monthLabel = cursor.toLocaleString(undefined, { month: "long", year: "numeric" });
  const today = new Date().toISOString().slice(0, 10);

  return (
    <div className="max-w-[1600px] mx-auto px-4 py-4">
      <div className="flex items-center gap-2 mb-3">
        <button className="btn" onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1))}>‹</button>
        <div className="text-xl font-black">{monthLabel}</div>
        <button className="btn" onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1))}>›</button>
        <button className="btn btn-ghost text-sm" onClick={() => setCursor(new Date())}>Today</button>
        <div className="flex-1" />
        <div className="text-sm opacity-70">Only cards with due dates appear here.</div>
      </div>

      <div className="glass-2 rounded-3xl p-3">
        <div className="grid grid-cols-7 text-xs opacity-70 mb-1">
          {["Sun","Mon","Tue","Wed","Thu","Fri","Sat"].map((d) => <div key={d} className="p-2">{d}</div>)}
        </div>
        <div className="grid grid-cols-7 gap-1">
          {monthCells.map((d, i) => {
            const iso = d.toISOString().slice(0, 10);
            const other = d.getMonth() !== cursor.getMonth();
            const items = byDate.get(iso) || [];
            const isToday = iso === today;
            return (
              <div key={i} className={`min-h-[110px] rounded-xl p-2 ${other ? "opacity-40" : ""}`} style={{ background: "var(--surface)", border: isToday ? "1px solid var(--accent)" : "1px solid var(--border)" }}>
                <div className={`text-xs font-bold ${isToday ? "" : "opacity-70"}`} style={isToday ? { color: "var(--accent)" } : undefined}>{d.getDate()}</div>
                <div className="mt-1 space-y-1">
                  {items.slice(0, 4).map((c) => (
                    <button
                      key={c.id}
                      onClick={() => setOpenCardId(c.id)}
                      className={`w-full text-left text-[11px] px-2 py-1 rounded-md truncate ${c.completed ? "line-through opacity-60" : ""}`}
                      style={{ background: "var(--surface-2)", borderLeft: `2px solid ${c.priority === "high" ? "var(--accent-2)" : c.priority === "med" ? "var(--warn)" : "var(--accent-3)"}` }}
                    >
                      {c.coverEmoji || "•"} {c.title}
                    </button>
                  ))}
                  {items.length > 4 && <div className="text-[10px] opacity-70">+{items.length - 4} more</div>}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {openCardId && <CardModal cardId={openCardId} onClose={() => setOpenCardId(null)} />}
    </div>
  );
}
