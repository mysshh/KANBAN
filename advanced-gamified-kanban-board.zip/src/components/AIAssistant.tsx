"use client";

import { useMemo, useState } from "react";
import { useStore } from "@/lib/store";
import { levelFromXp } from "@/lib/badges";

type Msg = { role: "user" | "bot"; text: string };

export function AIAssistant() {
  const { board, user } = useStore();
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([
    { role: "bot", text: "hey bestie 💜 i'm Slayte AI. ask me for priorities, blockers, streak intel, or say 'break this down: <goal>'." },
  ]);
  const [input, setInput] = useState("");

  const insights = useMemo(() => computeInsights(board), [board]);

  function ask(q: string) {
    const answer = answerFor(q, board, insights, user ? levelFromXp(user.xp).level : 1);
    setMessages((m) => [...m, { role: "user", text: q }, { role: "bot", text: answer }]);
    setInput("");
  }

  const suggestions = [
    "What should I do next?",
    "Any overdue tasks?",
    "How's my streak?",
    "Break this down: launch newsletter",
    "Explain XP",
  ];

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="fixed bottom-5 left-5 z-40 rounded-full w-14 h-14 grid place-items-center text-2xl shadow-2xl pulse-ring"
        style={{ background: "linear-gradient(135deg, var(--accent), var(--accent-2))" }}
        title="Slayte AI"
      >
        ✨
      </button>

      {open && (
        <div className="fixed inset-0 z-[90]" onClick={() => setOpen(false)}>
          <div className="absolute inset-0 bg-black/40" />
          <div
            onClick={(e) => e.stopPropagation()}
            className="absolute left-4 bottom-4 top-4 md:top-auto md:h-[600px] w-[calc(100%-2rem)] md:w-[400px] glass-2 rounded-3xl flex flex-col shadow-2xl"
          >
            <div className="p-4 flex items-center gap-3 border-b" style={{ borderColor: "var(--border)" }}>
              <div className="w-10 h-10 rounded-full grid place-items-center text-xl" style={{ background: "linear-gradient(135deg, var(--accent), var(--accent-2))" }}>✨</div>
              <div>
                <div className="font-bold">Slayte AI</div>
                <div className="text-xs opacity-70">Your board bestie</div>
              </div>
              <button className="ml-auto btn btn-ghost !px-2 !py-1" onClick={() => setOpen(false)}>✕</button>
            </div>
            <div className="flex-1 overflow-auto p-4 space-y-3 scrollbar-slim">
              {messages.map((m, i) => (
                <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                  <div className={`max-w-[85%] rounded-2xl px-3 py-2 text-sm whitespace-pre-wrap ${m.role === "user" ? "" : "glass"}`}
                       style={m.role === "user" ? { background: "linear-gradient(135deg, var(--accent), var(--accent-2))", color: "white" } : undefined}>
                    {m.text}
                  </div>
                </div>
              ))}
            </div>
            <div className="p-3 border-t" style={{ borderColor: "var(--border)" }}>
              <div className="flex gap-1 mb-2 overflow-x-auto scrollbar-slim">
                {suggestions.map((s) => (
                  <button key={s} className="chip whitespace-nowrap hover:!bg-white/15" onClick={() => ask(s)}>{s}</button>
                ))}
              </div>
              <form
                onSubmit={(e) => { e.preventDefault(); if (input.trim()) ask(input.trim()); }}
                className="flex gap-2"
              >
                <input className="input" placeholder="Ask Slayte…" value={input} onChange={(e) => setInput(e.target.value)} />
                <button className="btn btn-primary" type="submit">Send</button>
              </form>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

function computeInsights(board: ReturnType<typeof useStore>["board"]) {
  const today = new Date().toISOString().slice(0, 10);
  const overdue = board.cards.filter((c) => !c.completed && c.dueDate && c.dueDate < today);
  const dueToday = board.cards.filter((c) => !c.completed && c.dueDate === today);
  const highPri = board.cards.filter((c) => !c.completed && c.priority === "high");
  const blocked = board.cards.filter((c) => !c.completed && c.blockedBy.some((id) => {
    const dep = board.cards.find((x) => x.id === id); return dep && !dep.completed;
  }));
  const wipHot = board.columns.filter((col) => col.wipLimit && board.cards.filter((c) => c.columnId === col.id && !c.completed).length > col.wipLimit);
  return { overdue, dueToday, highPri, blocked, wipHot };
}

function answerFor(q: string, board: ReturnType<typeof useStore>["board"], ins: ReturnType<typeof computeInsights>, level: number) {
  const t = q.toLowerCase();
  if (t.startsWith("break this down:") || t.startsWith("break down:")) {
    const goal = q.split(":").slice(1).join(":").trim() || "the goal";
    return `okay let's break down "${goal}":\n\n1. Define the win (what does 'done' look like?)\n2. List the 3 biggest unknowns and research them\n3. Draft the outline / prototype\n4. Do the ugly first version\n5. Get one round of feedback\n6. Polish + ship\n\ntip: create 6 cards, one per step 🫶`;
  }
  if (t.includes("overdue") || t.includes("late")) {
    if (ins.overdue.length === 0) return "no overdue tasks — you're locked in 🔒✨";
    return `you have ${ins.overdue.length} overdue: ${ins.overdue.slice(0, 5).map((c) => `• ${c.title}`).join("\n")}${ins.overdue.length > 5 ? "\n…and more." : ""}\n\nsuggestion: knock out the smallest one first for momentum.`;
  }
  if (t.includes("streak") || t.includes("xp") || t.includes("level") || t.includes("gamif")) {
    return `you're level ${level}. XP: +5 per card created, +20 per completion, +10 daily login, +15 per focus session.\nkeep a daily streak to unlock the Week Warrior & Month Mode badges.`;
  }
  if (t.includes("next") || t.includes("priority") || t.includes("what should")) {
    const pick = ins.dueToday[0] || ins.highPri[0] || ins.overdue[0] || board.cards.find((c) => !c.completed);
    if (!pick) return "board's empty & vibing. add a card to get started.";
    return `try: "${pick.title}"${pick.dueDate ? ` (due ${pick.dueDate})` : ""}${pick.priority ? ` — ${pick.priority} priority` : ""}. small step forward > perfect plan.`;
  }
  if (t.includes("block")) {
    if (ins.blocked.length === 0) return "nothing blocked — you're free to fly 🕊️";
    return `blocked cards:\n${ins.blocked.slice(0, 5).map((c) => `• ${c.title}`).join("\n")}`;
  }
  if (t.includes("wip") || t.includes("limit")) {
    if (ins.wipHot.length === 0) return "WIP limits are chill.";
    return `over-limit columns: ${ins.wipHot.map((c) => c.title).join(", ")}. close some out before adding more.`;
  }
  if (t.includes("tip") || t.includes("productive") || t.includes("help")) {
    return "3-minute rule: any task under 3 min, do it now. also: batch similar tasks + protect one 90-min focus block a day. 💪";
  }
  return `here's the vibe: ${board.cards.filter((c) => !c.completed).length} open · ${ins.overdue.length} overdue · ${ins.dueToday.length} due today · ${ins.wipHot.length} WIP over limit.\nask me for priorities, blockers, or "break this down: <goal>".`;
}
