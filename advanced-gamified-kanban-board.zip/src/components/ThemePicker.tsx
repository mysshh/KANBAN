"use client";

import { useStore } from "@/lib/store";

const THEMES = [
  { id: "default", name: "Default", swatch: ["#a78bfa", "#f472b6", "#22d3ee"] },
  { id: "cyberpunk", name: "Cyberpunk", swatch: ["#00f5ff", "#ff006e", "#ffee00"] },
  { id: "cottagecore", name: "Cottagecore", swatch: ["#f4a261", "#e76f51", "#a3b18a"] },
  { id: "ocean", name: "Ocean", swatch: ["#48cae4", "#00b4d8", "#ffb703"] },
  { id: "sunset", name: "Sunset", swatch: ["#ffb347", "#ff6b6b", "#f7b2ad"] },
  { id: "space", name: "Space", swatch: ["#8b5cf6", "#ec4899", "#38bdf8"] },
  { id: "minimal", name: "Minimal", swatch: ["#6366f1", "#ec4899", "#10b981"] },
];

export function ThemePicker({ onClose }: { onClose: () => void }) {
  const { user, setTheme } = useStore();
  return (
    <div className="fixed inset-0 z-50" onClick={onClose}>
      <div className="absolute inset-0 bg-black/40" />
      <div
        onClick={(e) => e.stopPropagation()}
        className="absolute right-4 top-16 glass-2 rounded-3xl p-4 w-[320px] shadow-2xl"
      >
        <div className="flex items-center justify-between mb-3">
          <div className="font-bold">Pick a vibe</div>
          <button className="btn btn-ghost !px-2 !py-1 text-sm" onClick={onClose}>✕</button>
        </div>
        <div className="grid grid-cols-2 gap-2">
          {THEMES.map((t) => (
            <button
              key={t.id}
              onClick={() => setTheme(t.id)}
              className={`glass rounded-2xl p-3 text-left hover:scale-[1.02] transition ${user?.theme === t.id ? "ring-2 ring-offset-0" : ""}`}
              style={user?.theme === t.id ? { boxShadow: "0 0 0 2px var(--accent)" } : undefined}
            >
              <div className="flex gap-1 mb-2">
                {t.swatch.map((c, i) => (
                  <span key={i} className="w-6 h-6 rounded-full" style={{ background: c }} />
                ))}
              </div>
              <div className="text-sm font-semibold">{t.name}</div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
