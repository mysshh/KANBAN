"use client";

import { useStore } from "@/lib/store";

export function Toaster() {
  const { toasts, dismissToast } = useStore();
  return (
    <div className="fixed z-[200] bottom-4 right-4 flex flex-col gap-2 max-w-[360px]">
      {toasts.map((t) => (
        <button
          key={t.id}
          onClick={() => dismissToast(t.id)}
          className="toast-in text-left glass-2 rounded-2xl px-4 py-3 shadow-2xl cursor-pointer"
          style={{
            borderLeft: `4px solid ${
              t.kind === "xp" ? "var(--accent-3)" : t.kind === "level" ? "var(--accent)" : t.kind === "badge" ? "var(--accent-2)" : t.kind === "error" ? "var(--danger)" : "var(--border)"
            }`,
          }}
        >
          <div className="font-semibold text-sm">{t.title}</div>
          {t.body && <div className="text-xs opacity-80 mt-0.5">{t.body}</div>}
        </button>
      ))}
    </div>
  );
}
