"use client";

import { useMemo, useState } from "react";
import { useStore } from "@/lib/store";
import type { Card } from "@/lib/types";
import { CardModal } from "./CardModal";
import { TEMPLATES } from "@/lib/templates";

export function KanbanBoard({ readOnly = false }: { readOnly?: boolean }) {
  const { board, addCard, moveCard, updateCard, addColumn, renameColumn, removeColumn, setWipLimit, toggleComplete, togglePublic } = useStore();
  const [openCardId, setOpenCardId] = useState<string | null>(null);
  const [addingIn, setAddingIn] = useState<string | null>(null);
  const [templateOpen, setTemplateOpen] = useState<string | null>(null);
  const [renamingCol, setRenamingCol] = useState<string | null>(null);
  const [editingCardId, setEditingCardId] = useState<string | null>(null);
  const [editingText, setEditingText] = useState("");
  const [dragOverCol, setDragOverCol] = useState<string | null>(null);
  const [showShare, setShowShare] = useState(false);

  const cardsByCol = useMemo(() => {
    const map = new Map<string, Card[]>();
    for (const col of board.columns) map.set(col.id, []);
    for (const c of board.cards) {
      if (!map.has(c.columnId)) map.set(c.columnId, []);
      map.get(c.columnId)!.push(c);
    }
    for (const arr of map.values()) arr.sort((a, b) => a.order - b.order);
    return map;
  }, [board]);

  function onDragStartCard(e: React.DragEvent, card: Card) {
    e.dataTransfer.setData("text/card-id", card.id);
    e.dataTransfer.effectAllowed = "move";
  }
  function onDropColumn(e: React.DragEvent, colId: string) {
    e.preventDefault();
    const id = e.dataTransfer.getData("text/card-id");
    if (!id) return;
    const dest = cardsByCol.get(colId) || [];
    moveCard(id, colId, dest.length);
    setDragOverCol(null);
  }
  function onDropCard(e: React.DragEvent, target: Card) {
    e.preventDefault(); e.stopPropagation();
    const id = e.dataTransfer.getData("text/card-id");
    if (!id || id === target.id) return;
    const destIndex = target.order;
    moveCard(id, target.columnId, destIndex);
    setDragOverCol(null);
  }

  const shareUrl = typeof window !== "undefined" ? `${window.location.origin}/share/${board.shareId}` : "";

  return (
    <div className="max-w-[1600px] mx-auto px-4 py-4">
      {!readOnly && (
        <div className="flex flex-wrap items-center gap-2 mb-4">
          <div className="text-xl font-black">{board.name}</div>
          <div className="chip">{board.cards.filter(c => !c.completed).length} open</div>
          <div className="chip">{board.cards.filter(c => c.completed).length} done</div>
          <div className="flex-1" />
          <button className="btn" onClick={() => setShowShare((v) => !v)}>🔗 Share</button>
          <ExportMenu />
          <button className="btn btn-primary" onClick={() => { const t = prompt("New column title", "New column"); if (t) addColumn(t); }}>+ Column</button>
        </div>
      )}

      {showShare && !readOnly && (
        <div className="glass-2 rounded-2xl p-4 mb-4">
          <div className="flex items-center gap-3 flex-wrap">
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={board.isPublic} onChange={togglePublic} />
              Public board (read-only link)
            </label>
            {board.isPublic && (
              <>
                <input readOnly className="input flex-1 min-w-[240px]" value={shareUrl} onClick={(e) => (e.target as HTMLInputElement).select()} />
                <button className="btn" onClick={() => navigator.clipboard?.writeText(shareUrl)}>Copy</button>
              </>
            )}
          </div>
          <div className="text-xs opacity-70 mt-2">Public boards use the same browser&apos;s localStorage — best for showing friends on the same device or PWA.</div>
        </div>
      )}

      <div className="flex gap-4 overflow-x-auto pb-6 scrollbar-slim snap-x">
        {board.columns.sort((a, b) => a.order - b.order).map((col) => {
          const cards = cardsByCol.get(col.id) || [];
          const activeCount = cards.filter((c) => !c.completed).length;
          const overWip = col.wipLimit && activeCount > col.wipLimit;
          const wipPct = col.wipLimit ? Math.min(100, (activeCount / col.wipLimit) * 100) : 0;
          return (
            <div
              key={col.id}
              className={`shrink-0 w-[320px] snap-start glass-2 rounded-3xl p-3 flex flex-col transition ${dragOverCol === col.id ? "column-drag-over" : ""}`}
              onDragOver={(e) => { e.preventDefault(); setDragOverCol(col.id); }}
              onDragLeave={() => setDragOverCol((c) => (c === col.id ? null : c))}
              onDrop={(e) => onDropColumn(e, col.id)}
            >
              <div className="flex items-center gap-2 mb-2">
                <span className="w-2.5 h-2.5 rounded-full" style={{ background: col.color || "var(--accent)" }} />
                {renamingCol === col.id && !readOnly ? (
                  <input
                    autoFocus
                    className="input !py-1 text-sm"
                    defaultValue={col.title}
                    onBlur={(e) => { renameColumn(col.id, e.target.value.trim() || col.title); setRenamingCol(null); }}
                    onKeyDown={(e) => { if (e.key === "Enter") (e.target as HTMLInputElement).blur(); }}
                  />
                ) : (
                  <button className="font-bold" onDoubleClick={() => !readOnly && setRenamingCol(col.id)}>{col.title}</button>
                )}
                <span className="chip !text-xs">{activeCount}{col.wipLimit ? `/${col.wipLimit}` : ""}</span>
                {!readOnly && (
                  <div className="ml-auto flex items-center gap-1">
                    <button className="opacity-60 hover:opacity-100 text-xs" title="Set WIP limit" onClick={() => {
                      const v = prompt("WIP limit (leave empty to remove)", col.wipLimit?.toString() || "");
                      if (v === null) return;
                      if (v.trim() === "") setWipLimit(col.id, undefined);
                      else { const n = Number(v); if (!isNaN(n) && n > 0) setWipLimit(col.id, n); }
                    }}>⚑</button>
                    <button className="opacity-60 hover:opacity-100 text-xs" title="Delete column" onClick={() => confirm(`Delete column "${col.title}" and its cards?`) && removeColumn(col.id)}>✕</button>
                  </div>
                )}
              </div>

              {col.wipLimit != null && (
                <div className="mb-2">
                  <div className="w-full h-1 rounded-full overflow-hidden" style={{ background: "var(--surface-2)" }}>
                    <div
                      className="h-full transition-all"
                      style={{
                        width: `${wipPct}%`,
                        background: overWip
                          ? "linear-gradient(90deg, #ef4444, #f97316)"
                          : wipPct >= 80
                            ? "linear-gradient(90deg, #fbbf24, #f97316)"
                            : "linear-gradient(90deg, var(--accent-3), var(--accent))",
                      }}
                    />
                  </div>
                  {overWip && (
                    <div className="text-[10px] mt-1 flex items-center gap-1" style={{ color: "var(--danger)" }}>⚠ over WIP limit ({activeCount}/{col.wipLimit})</div>
                  )}
                </div>
              )}

              <div className="flex flex-col gap-2 flex-1 min-h-[40px]">
                {cards.map((c) => {
                  const blocked = c.blockedBy.some((id) => {
                    const dep = board.cards.find((x) => x.id === id);
                    return dep && !dep.completed;
                  });
                  const subs = c.subtasks;
                  const subDone = subs.filter((s) => s.done).length;
                  const overdue = !c.completed && c.dueDate && c.dueDate < new Date().toISOString().slice(0, 10);
                  return (
                    <div
                      key={c.id}
                      draggable={!readOnly}
                      onDragStart={(e) => onDragStartCard(e, c)}
                      onDrop={(e) => onDropCard(e, c)}
                      onDragOver={(e) => e.preventDefault()}
                      onClick={() => setOpenCardId(c.id)}
                      className={`glass rounded-2xl p-3 cursor-pointer hover:-translate-y-0.5 transition ${c.completed ? "opacity-60" : ""}`}
                      style={{ borderLeft: blocked ? "3px solid var(--danger)" : c.priority === "high" ? "3px solid var(--accent-2)" : c.priority === "med" ? "3px solid var(--warn)" : undefined }}
                    >
                      <div className="flex items-start gap-2">
                        {c.coverEmoji && <div className="text-xl">{c.coverEmoji}</div>}
                        <div className="flex-1 min-w-0">
                          {editingCardId === c.id ? (
                            <input
                              autoFocus
                              value={editingText}
                              onChange={(e) => setEditingText(e.target.value)}
                              onBlur={() => { updateCard(c.id, { title: editingText.trim() || c.title }); setEditingCardId(null); }}
                              onKeyDown={(e) => {
                                if (e.key === "Enter") (e.target as HTMLInputElement).blur();
                                if (e.key === "Escape") setEditingCardId(null);
                              }}
                              onClick={(e) => e.stopPropagation()}
                              className="input !py-1 text-sm"
                            />
                          ) : (
                            <div
                              className={`font-semibold text-sm no-select ${c.completed ? "line-through" : ""}`}
                              onDoubleClick={(e) => { e.stopPropagation(); if (!readOnly) { setEditingCardId(c.id); setEditingText(c.title); } }}
                              title="Double-click to edit"
                            >
                              {c.title}
                            </div>
                          )}
                          {c.description && <div className="text-xs opacity-70 mt-1 line-clamp-2 whitespace-pre-wrap">{c.description}</div>}
                          <div className="flex flex-wrap gap-1 mt-2">
                            {overdue && <span className="chip !bg-rose-500/25">⏰ overdue</span>}
                            {blocked && <span className="chip !bg-rose-500/25">🔒 blocked</span>}
                            {c.dueDate && <span className="chip">📅 {c.dueDate.slice(5)}</span>}
                            {c.recurring && <span className="chip">🔁 {c.recurring.pattern}</span>}
                            {subs.length > 0 && <span className="chip">☑ {subDone}/{subs.length}</span>}
                            {c.activeTimerStart != null && <span className="chip !bg-amber-500/25">⏱ running</span>}
                            {c.labels.slice(0, 3).map((l) => (<span key={l} className="chip !bg-white/10">#{l}</span>))}
                          </div>
                          {c.reactions.length > 0 && (
                            <div className="flex gap-1 mt-1.5">
                              {c.reactions.map((r) => (<span key={r.emoji} className="chip !text-[11px]">{r.emoji} {r.users.length}</span>))}
                            </div>
                          )}
                        </div>
                        {!readOnly && (
                          <button
                            className="opacity-60 hover:opacity-100 text-lg"
                            onClick={(e) => { e.stopPropagation(); toggleComplete(c.id); }}
                            title={c.completed ? "Mark undone" : "Mark done"}
                          >
                            {c.completed ? "☑" : "☐"}
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {!readOnly && (
                <div className="mt-2">
                  {addingIn === col.id ? (
                    <AddCardForm
                      onCancel={() => setAddingIn(null)}
                      onAdd={(title) => { addCard(col.id, { title }); setAddingIn(null); }}
                    />
                  ) : (
                    <div className="flex gap-1">
                      <button className="btn btn-ghost flex-1 !py-2 justify-start text-sm" onClick={() => setAddingIn(col.id)}>+ Add card</button>
                      <button className="btn btn-ghost !px-3" title="Templates" onClick={() => setTemplateOpen(col.id)}>📋</button>
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {templateOpen && (
        <div className="fixed inset-0 z-[70] grid place-items-center" onClick={() => setTemplateOpen(null)}>
          <div className="absolute inset-0 bg-black/50" />
          <div onClick={(e) => e.stopPropagation()} className="relative glass-2 rounded-3xl p-5 w-[min(560px,95vw)]">
            <div className="flex items-center justify-between mb-3">
              <div className="font-bold">Start from template</div>
              <button className="btn btn-ghost !px-2 !py-1" onClick={() => setTemplateOpen(null)}>✕</button>
            </div>
            <div className="grid sm:grid-cols-2 gap-2">
              {TEMPLATES.map((t) => (
                <button
                  key={t.id}
                  className="glass rounded-2xl p-3 text-left hover:-translate-y-0.5 transition"
                  onClick={() => {
                    addCard(templateOpen!, t.card);
                    setTemplateOpen(null);
                  }}
                >
                  <div className="text-xl">{t.emoji}</div>
                  <div className="font-semibold mt-1">{t.name}</div>
                  <div className="text-xs opacity-70">{t.card.description?.slice(0, 60)}…</div>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {openCardId && <CardModal cardId={openCardId} onClose={() => setOpenCardId(null)} />}
    </div>
  );
}

function AddCardForm({ onAdd, onCancel }: { onAdd: (title: string) => void; onCancel: () => void }) {
  const [v, setV] = useState("");
  return (
    <form onSubmit={(e) => { e.preventDefault(); if (v.trim()) onAdd(v.trim()); }} className="flex gap-1">
      <input autoFocus className="input !py-2 text-sm" placeholder="Card title" value={v} onChange={(e) => setV(e.target.value)} onKeyDown={(e) => { if (e.key === "Escape") onCancel(); }} />
      <button className="btn btn-primary !px-3" type="submit">Add</button>
    </form>
  );
}

function ExportMenu() {
  const { board } = useStore();
  const [open, setOpen] = useState(false);

  function exportJson() {
    const blob = new Blob([JSON.stringify(board, null, 2)], { type: "application/json" });
    download(blob, `slayte-board-${Date.now()}.json`);
    setOpen(false);
  }
  function exportCsv() {
    const header = ["id","title","column","priority","dueDate","completed","labels","subtasksDone","subtasksTotal"];
    const rows = board.cards.map((c) => [
      c.id, csv(c.title), csv(board.columns.find((k) => k.id === c.columnId)?.title || ""),
      c.priority || "", c.dueDate || "", c.completed ? "1" : "0",
      csv(c.labels.join("|")), c.subtasks.filter((s) => s.done).length, c.subtasks.length,
    ]);
    const text = [header.join(","), ...rows.map((r) => r.join(","))].join("\n");
    const blob = new Blob([text], { type: "text/csv" });
    download(blob, `slayte-board-${Date.now()}.csv`);
    setOpen(false);
  }
  return (
    <div className="relative">
      <button className="btn" onClick={() => setOpen((v) => !v)}>⬇ Export</button>
      {open && (
        <div className="absolute right-0 top-12 glass-2 rounded-2xl p-2 z-30 w-40">
          <button className="btn btn-ghost w-full justify-start" onClick={exportJson}>JSON</button>
          <button className="btn btn-ghost w-full justify-start" onClick={exportCsv}>CSV</button>
        </div>
      )}
    </div>
  );
}

function csv(s: string) {
  if (s.includes(",") || s.includes('"') || s.includes("\n")) return `"${s.replace(/"/g, '""')}"`;
  return s;
}
function download(blob: Blob, name: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a"); a.href = url; a.download = name; a.click();
  URL.revokeObjectURL(url);
}
