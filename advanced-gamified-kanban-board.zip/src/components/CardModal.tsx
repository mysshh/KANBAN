"use client";

import { useEffect, useMemo, useState } from "react";
import { useStore } from "@/lib/store";
import type { Card, Priority } from "@/lib/types";

const REACTION_EMOJIS = ["👍", "🔥", "🚀", "💯", "❤️", "😂", "👀", "🎉", "🥲", "💀"];
const COVER_EMOJIS = ["✨","🚀","🔥","💜","🎯","📌","💡","🐛","📝","🗒️","🌸","🌈","⚡","🎨","🧠","🫶"];

export function CardModal({ cardId, onClose }: { cardId: string; onClose: () => void }) {
  const { board, updateCard, removeCard, toggleComplete, addSubtask, toggleSubtask, removeSubtask, startTimer, stopTimer, toggleReaction, setRecurring } = useStore();
  const card = board.cards.find((c) => c.id === cardId);
  const [subInput, setSubInput] = useState("");
  const [tick, setTick] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setTick((v) => v + 1), 1000);
    return () => clearInterval(t);
  }, []);

  const totalMs = useMemo(() => {
    if (!card) return 0;
    let ms = card.timeEntries.reduce((a, e) => a + ((e.end || Date.now()) - e.start), 0);
    if (card.activeTimerStart) ms += Date.now() - card.activeTimerStart;
    return ms;
  }, [card, tick]);

  if (!card) return null;

  const doneCount = card.subtasks.filter((s) => s.done).length;
  const subtaskPct = card.subtasks.length ? Math.round((doneCount / card.subtasks.length) * 100) : 0;

  const otherCards = board.cards.filter((c) => c.id !== card.id);

  const blockingOpen = card.blockedBy
    .map((id) => board.cards.find((c) => c.id === id))
    .filter((c): c is Card => !!c);

  return (
    <div className="fixed inset-0 z-[80]" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60" />
      <div
        onClick={(e) => e.stopPropagation()}
        className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[min(720px,95vw)] max-h-[90vh] overflow-auto glass-2 rounded-3xl shadow-2xl scrollbar-slim"
      >
        <div className="p-5 border-b flex items-start gap-3" style={{ borderColor: "var(--border)" }}>
          <div className="text-3xl">{card.coverEmoji || "📌"}</div>
          <div className="flex-1">
            <input
              className="input text-lg font-bold !py-1"
              value={card.title}
              onChange={(e) => updateCard(card.id, { title: e.target.value })}
            />
            <div className="flex items-center gap-2 mt-2 flex-wrap">
              <button className={`chip ${card.completed ? "!bg-emerald-500/25" : ""}`} onClick={() => toggleComplete(card.id)}>
                {card.completed ? "✅ Completed" : "◻ Mark done"}
              </button>
              <select
                className="chip !bg-white/5 !text-inherit"
                value={card.priority || ""}
                onChange={(e) => updateCard(card.id, { priority: (e.target.value || undefined) as Priority | undefined })}
              >
                <option value="">no priority</option>
                <option value="low">low</option>
                <option value="med">medium</option>
                <option value="high">high</option>
              </select>
              <input
                type="date"
                className="chip !bg-white/5"
                value={card.dueDate || ""}
                onChange={(e) => updateCard(card.id, { dueDate: e.target.value || undefined })}
              />
              <select
                className="chip !bg-white/5"
                value={card.recurring?.pattern || ""}
                onChange={(e) => {
                  const p = e.target.value as "daily" | "weekly" | "monthly" | "";
                  if (!p) setRecurring(card.id, null);
                  else setRecurring(card.id, { pattern: p, lastSpawnedAt: Date.now() });
                }}
              >
                <option value="">not recurring</option>
                <option value="daily">daily</option>
                <option value="weekly">weekly</option>
                <option value="monthly">monthly</option>
              </select>
            </div>
          </div>
          <button className="btn btn-ghost !px-3" onClick={onClose}>✕</button>
        </div>

        <div className="p-5 grid md:grid-cols-3 gap-5">
          <div className="md:col-span-2 space-y-5">
            <section>
              <label className="text-xs uppercase opacity-70 tracking-wider">Description</label>
              <textarea
                className="textarea mt-1 min-h-[110px]"
                placeholder="Vibes, context, links…"
                value={card.description || ""}
                onChange={(e) => updateCard(card.id, { description: e.target.value })}
              />
            </section>

            <section>
              <div className="flex items-center justify-between">
                <label className="text-xs uppercase opacity-70 tracking-wider">Subtasks</label>
                <div className="text-xs opacity-80">{doneCount}/{card.subtasks.length} · {subtaskPct}%</div>
              </div>
              {card.subtasks.length > 0 && (
                <div className="w-full h-1.5 rounded-full my-2 overflow-hidden" style={{ background: "var(--surface-2)" }}>
                  <div className="h-full transition-all" style={{ width: `${subtaskPct}%`, background: "linear-gradient(90deg, var(--accent), var(--accent-3))" }} />
                </div>
              )}
              <ul className="space-y-1">
                {card.subtasks.map((s) => (
                  <li key={s.id} className="flex items-center gap-2">
                    <input type="checkbox" checked={s.done} onChange={() => toggleSubtask(card.id, s.id)} />
                    <span className={`flex-1 text-sm ${s.done ? "line-through opacity-60" : ""}`}>{s.title}</span>
                    <button className="opacity-50 hover:opacity-100 text-xs" onClick={() => removeSubtask(card.id, s.id)}>✕</button>
                  </li>
                ))}
              </ul>
              <form
                className="flex gap-2 mt-2"
                onSubmit={(e) => { e.preventDefault(); if (subInput.trim()) { addSubtask(card.id, subInput.trim()); setSubInput(""); } }}
              >
                <input className="input" placeholder="Add subtask…" value={subInput} onChange={(e) => setSubInput(e.target.value)} />
                <button className="btn" type="submit">Add</button>
              </form>
            </section>

            <section>
              <label className="text-xs uppercase opacity-70 tracking-wider">Blocked by</label>
              <div className="flex flex-wrap gap-1 mt-1">
                {blockingOpen.map((b) => (
                  <span key={b.id} className="chip !bg-rose-500/20">
                    🔒 {b.title}
                    <button className="ml-1 opacity-70" onClick={() => updateCard(card.id, { blockedBy: card.blockedBy.filter((x) => x !== b.id) })}>✕</button>
                  </span>
                ))}
              </div>
              <select
                className="input mt-2"
                value=""
                onChange={(e) => {
                  const id = e.target.value;
                  if (!id) return;
                  if (!card.blockedBy.includes(id)) updateCard(card.id, { blockedBy: [...card.blockedBy, id] });
                }}
              >
                <option value="">+ add dependency…</option>
                {otherCards.map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}
              </select>
            </section>

            <section>
              <label className="text-xs uppercase opacity-70 tracking-wider">Reactions</label>
              <div className="flex flex-wrap gap-1 mt-2">
                {card.reactions.map((r) => (
                  <button key={r.emoji} className="chip !bg-white/10" onClick={() => toggleReaction(card.id, r.emoji)}>
                    {r.emoji} {r.users.length}
                  </button>
                ))}
                <div className="flex flex-wrap gap-1 mt-1">
                  {REACTION_EMOJIS.map((e) => (
                    <button key={e} className="hover:scale-125 transition text-lg" onClick={() => toggleReaction(card.id, e)}>{e}</button>
                  ))}
                </div>
              </div>
            </section>
          </div>

          <aside className="space-y-4">
            <section>
              <label className="text-xs uppercase opacity-70 tracking-wider">Cover emoji</label>
              <div className="grid grid-cols-8 gap-1 mt-2">
                {COVER_EMOJIS.map((e) => (
                  <button key={e} className={`text-lg glass rounded-lg py-1 ${card.coverEmoji === e ? "ring-2" : ""}`} style={card.coverEmoji === e ? { boxShadow: "0 0 0 2px var(--accent)" } : undefined} onClick={() => updateCard(card.id, { coverEmoji: e })}>{e}</button>
                ))}
              </div>
              {card.coverEmoji && (
                <button className="text-xs opacity-60 mt-2" onClick={() => updateCard(card.id, { coverEmoji: undefined })}>clear cover</button>
              )}
            </section>

            <section className="glass rounded-2xl p-3">
              <div className="text-xs uppercase opacity-70 tracking-wider">Time tracked</div>
              <div className="font-black text-2xl mt-1">{fmt(totalMs)}</div>
              <button
                className={`btn mt-2 w-full ${card.activeTimerStart ? "!bg-rose-500/30" : "btn-primary"}`}
                onClick={() => (card.activeTimerStart ? stopTimer(card.id) : startTimer(card.id))}
              >
                {card.activeTimerStart ? "⏹ Stop" : "▶ Start timer"}
              </button>
            </section>

            <section>
              <label className="text-xs uppercase opacity-70 tracking-wider">Labels</label>
              <input
                className="input mt-1 text-sm"
                placeholder="comma, separated"
                value={card.labels.join(", ")}
                onChange={(e) => updateCard(card.id, { labels: e.target.value.split(",").map((s) => s.trim()).filter(Boolean) })}
              />
            </section>

            <button className="btn w-full !bg-rose-500/25" onClick={() => { removeCard(card.id); onClose(); }}>🗑 Delete card</button>
          </aside>
        </div>
      </div>
    </div>
  );
}

function fmt(ms: number) {
  const s = Math.floor(ms / 1000);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  const pad = (n: number) => n.toString().padStart(2, "0");
  return `${pad(h)}:${pad(m)}:${pad(sec)}`;
}
