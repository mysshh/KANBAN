"use client";

import React from "react";
import { StoreProvider, useStore } from "@/lib/store";
import { Toaster } from "./Toaster";
import { TopBar } from "./TopBar";
import { AIAssistant } from "./AIAssistant";
import { usePathname } from "next/navigation";

function Chrome({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const isPublic = pathname?.startsWith("/share") || pathname === "/";
  const { user } = useStore();

  return (
    <div className="min-h-screen relative">
      {/* Ambient orbs */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="orb w-[420px] h-[420px] -top-24 -left-24" style={{ background: "var(--accent)" }} />
        <div className="orb w-[520px] h-[520px] top-1/3 -right-32" style={{ background: "var(--accent-2)" }} />
        <div className="orb w-[360px] h-[360px] bottom-0 left-1/3" style={{ background: "var(--accent-3)" }} />
      </div>

      {!isPublic && user && <TopBar />}
      <div className="relative">{children}</div>
      {!isPublic && user && <AIAssistant />}
      <Toaster />
    </div>
  );
}

export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <StoreProvider>
      <Chrome>{children}</Chrome>
    </StoreProvider>
  );
}
