"use client";

import { useStore } from "@/lib/store";
import Link from "next/link";
import { useState } from "react";
import { levelFromXp } from "@/lib/badges";
import { ThemePicker } from "./ThemePicker";
import { MusicPlayer } from "./MusicPlayer";
import { FocusMode } from "./FocusMode";

export function TopBar() {
  const { user, logout } = useStore();
  const [themeOpen, setThemeOpen] = useState(false);
  const [focusOpen, setFocusOpen] = useState(false);
  if (!user) return null;
  const lv = levelFromXp(user.xp);

  return (
    <>
      <header className="sticky top-0 z-40 backdrop-blur-xl" style={{ background: "color-mix(in oklab, var(--bg-1) 70%, transparent)", borderBottom: "1px solid var(--border)" }}>
        <div className="max-w-[1600px] mx-auto px-4 py-3 flex items-center gap-3">
          <Link href="/board" className="flex items-center gap-2 mr-2">
            <Logo size={30} />
            <div className="font-black tracking-tight text-lg">
              <span className="gradient-text">Slayte</span>
            </div>
          </Link>
          <nav className="flex items-center gap-1">
            <NavLink href="/board" label="Board" />
            <NavLink href="/vibe-check" label="Vibe check" />
          </nav>
          <div className="flex-1" />
          <MusicPlayer />
          <button className="btn btn-ghost !px-3" title="Focus mode" onClick={() => setFocusOpen(true)}>🎯</button>
          <button className="btn btn-ghost !px-3" title="Themes" onClick={() => setThemeOpen((v) => !v)}>🎨</button>

          <div className="hidden sm:flex items-center gap-2 glass rounded-full px-3 py-1.5">
            <div className="text-xs opacity-70">Lv</div>
            <div className="font-bold text-sm">{lv.level}</div>
            <div className="w-24 h-1.5 rounded-full overflow-hidden" style={{ background: "var(--surface-2)" }}>
              <div className="h-full rounded-full" style={{ width: `${(lv.progress / lv.needed) * 100}%`, background: "linear-gradient(90deg, var(--accent), var(--accent-2))" }} />
            </div>
            <div className="text-xs opacity-70">{lv.progress}/{lv.needed} XP</div>
          </div>

          <div className="glass rounded-full px-3 py-1.5 flex items-center gap-2">
            <div className="w-7 h-7 rounded-full grid place-items-center font-bold text-sm" style={{ background: "linear-gradient(135deg, var(--accent), var(--accent-2))" }}>{user.username[0]?.toUpperCase()}</div>
            <div className="text-sm hidden md:block">{user.username}</div>
            <button className="text-xs opacity-70 hover:opacity-100" onClick={logout} title="Log out">↩</button>
          </div>
        </div>
      </header>

      {themeOpen && <ThemePicker onClose={() => setThemeOpen(false)} />}
      {focusOpen && <FocusMode onClose={() => setFocusOpen(false)} />}
    </>
  );
}

function NavLink({ href, label }: { href: string; label: string }) {
  return (
    <Link href={href} className="btn btn-ghost !px-3 !py-1.5 text-sm">{label}</Link>
  );
}

export function Logo({ size = 32 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="lg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="var(--accent)"/>
          <stop offset="50%" stopColor="var(--accent-2)"/>
          <stop offset="100%" stopColor="var(--accent-3)"/>
        </linearGradient>
      </defs>
      <rect x="4" y="4" width="56" height="56" rx="16" fill="url(#lg)"/>
      <g fill="var(--bg-1)">
        <rect x="13" y="17" width="10" height="30" rx="3"/>
        <rect x="27" y="17" width="10" height="22" rx="3"/>
        <rect x="41" y="17" width="10" height="14" rx="3"/>
      </g>
      <circle cx="49" cy="47" r="8" fill="var(--bg-1)"/>
      <text x="49" y="51" textAnchor="middle" fontFamily="system-ui" fontWeight="900" fontSize="10" fill="var(--accent-2)">✦</text>
    </svg>
  );
}
