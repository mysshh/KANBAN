"use client";

import { useEffect, useRef, useState } from "react";
import { useStore } from "@/lib/store";

type Phase = "work" | "short" | "long";
const DURATIONS: Record<Phase, number> = { work: 25 * 60, short: 5 * 60, long: 15 * 60 };
const LABELS: Record<Phase, string> = { work: "Focus", short: "Short break", long: "Long break" };
const GLOW: Record<Phase, string> = {
  work: "var(--accent)",
  short: "var(--accent-3)",
  long: "var(--accent-2)",
};

export function FocusMode({ onClose }: { onClose: () => void }) {
  const { bumpStat, addXp, pushToast } = useStore();
  const [phase, setPhase] = useState<Phase>("work");
  const [remaining, setRemaining] = useState<number>(DURATIONS.work);
  const [running, setRunning] = useState<boolean>(false);
  const [sessions, setSessions] = useState<number>(0);
  const tickRef = useRef<number | null>(null);

  useEffect(() => {
    if (!running) return;
    tickRef.current = window.setInterval(() => {
      setRemaining((r) => {
        if (r <= 1) {
          window.clearInterval(tickRef.current!);
          onComplete();
          return 0;
        }
        return r - 1;
      });
    }, 1000);
    return () => { if (tickRef.current) window.clearInterval(tickRef.current); };
  }, [running]); // eslint-disable-line react-hooks/exhaustive-deps

  function onComplete() {
    setRunning(false);
    if (phase === "work") {
      const nextSessions = sessions + 1;
      setSessions(nextSessions);
      bumpStat("focusSessions");
      addXp(15, "Focus session done");
      pushToast({ kind: "info", title: "🎯 Session complete — nice work" });
      const next: Phase = nextSessions % 4 === 0 ? "long" : "short";
      setPhase(next);
      setRemaining(DURATIONS[next]);
    } else {
      setPhase("work");
      setRemaining(DURATIONS.work);
      pushToast({ kind: "info", title: "Break's over — let's slay" });
    }
  }

  function switchPhase(p: Phase) { setPhase(p); setRemaining(DURATIONS[p]); setRunning(false); }
  function reset() { setRemaining(DURATIONS[phase]); setRunning(false); }

  const total = DURATIONS[phase];
  const pct = 1 - remaining / total;
  const mins = Math.floor(remaining / 60).toString().padStart(2, "0");
  const secs = (remaining % 60).toString().padStart(2, "0");
  const R = 130;
  const C = 2 * Math.PI * R;

  return (
    <div className="fixed inset-0 z-[100] grid place-items-center" style={{ background: "color-mix(in oklab, var(--bg-1) 92%, black)" }}>
      <div className="absolute top-4 right-4 flex items-center gap-2">
        <button className="btn" onClick={onClose}>✕ Exit</button>
      </div>

      <div className="text-center px-6">
        <div className="text-xs uppercase tracking-[0.4em] opacity-70 mb-2">Focus mode</div>
        <div className="text-3xl md:text-4xl font-black mb-8">{LABELS[phase]}</div>

        <div className="relative mx-auto" style={{ width: 320, height: 320 }}>
          <div className="absolute inset-0 rounded-full pulse-ring" style={{ boxShadow: `0 0 120px ${GLOW[phase]}, 0 0 60px ${GLOW[phase]}`, background: `radial-gradient(circle, color-mix(in oklab, ${GLOW[phase]} 20%, transparent), transparent 70%)` }} />
          <svg width={320} height={320} viewBox="0 0 320 320" className="relative">
            <circle cx="160" cy="160" r={R} stroke="var(--border)" strokeWidth={10} fill="none" />
            <circle
              cx="160" cy="160" r={R}
              stroke={GLOW[phase]} strokeWidth={12} fill="none" strokeLinecap="round"
              strokeDasharray={C} strokeDashoffset={C - pct * C}
              transform="rotate(-90 160 160)"
              style={{ transition: "stroke-dashoffset 1s linear" }}
            />
            <text x="160" y="170" textAnchor="middle" fontSize="64" fontWeight="900" fill="var(--text)">{mins}:{secs}</text>
          </svg>
        </div>

        <div className="flex items-center justify-center gap-2 mt-8">
          <button className="btn btn-primary" onClick={() => setRunning((v) => !v)}>{running ? "⏸ Pause" : "▶ Start"}</button>
          <button className="btn" onClick={reset}>Reset</button>
        </div>

        <div className="mt-6 flex items-center justify-center gap-2">
          {(["work", "short", "long"] as Phase[]).map((p) => (
            <button key={p} className={`chip ${phase === p ? "!bg-white/20" : ""}`} onClick={() => switchPhase(p)}>{LABELS[p]}</button>
          ))}
        </div>

        <div className="mt-6 text-sm opacity-70">Sessions today: <span className="font-bold">{sessions}</span></div>
      </div>
    </div>
  );
}
