"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useState, Suspense } from "react";
import Link from "next/link";
import { useStore } from "@/lib/store";
import { Logo } from "@/components/TopBar";

function LoginInner() {
  const { login, user } = useStore();
  const router = useRouter();
  const sp = useSearchParams();
  const [name, setName] = useState(user?.username || "");
  const isSignup = sp.get("signup") === "1";

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const n = name.trim();
    if (!n) return;
    login(n);
    router.push("/board");
  }

  return (
    <main className="min-h-screen grid place-items-center px-4">
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 text-6xl animate-float-slow">🪐</div>
        <div className="absolute bottom-20 right-10 text-6xl animate-float-slow" style={{ animationDelay: "1s" }}>🚀</div>
      </div>
      <div className="glass-2 rounded-3xl p-8 w-[min(440px,95vw)] relative">
        <Link href="/" className="flex items-center gap-2 mb-6">
          <Logo size={36} />
          <div className="font-black text-2xl gradient-text">Slayte</div>
        </Link>
        <h1 className="text-2xl font-black">{isSignup ? "Create account" : "Welcome back"}</h1>
        <p className="opacity-70 text-sm mt-1">
          {isSignup ? "Pick a vibey username. No password needed — this app runs on your device." : "Type your username to jump back in. New here? Any name works."}
        </p>
        <form onSubmit={submit} className="mt-5 space-y-3">
          <div>
            <label className="text-xs opacity-70">Username</label>
            <input autoFocus className="input mt-1" placeholder="e.g. sparkleboss" value={name} onChange={(e) => setName(e.target.value)} maxLength={24} />
          </div>
          <button className="btn btn-primary w-full" type="submit">{isSignup ? "Start slaying →" : "Log me in →"}</button>
          <div className="text-xs opacity-60 text-center">
            {isSignup ? "already have one? " : "new? "}
            <Link href={isSignup ? "/login" : "/login?signup=1"} className="underline opacity-80">
              {isSignup ? "login" : "create account"}
            </Link>
          </div>
        </form>
      </div>
    </main>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={<div className="p-8">loading…</div>}>
      <LoginInner />
    </Suspense>
  );
}
