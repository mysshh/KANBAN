"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useStore } from "@/lib/store";
import { KanbanBoard } from "@/components/KanbanBoard";
import { CalendarView } from "@/components/CalendarView";

export default function BoardPage() {
  const { user } = useStore();
  const router = useRouter();
  const [view, setView] = useState<"board" | "calendar">("board");
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setReady(true);
  }, []);

  useEffect(() => {
    if (ready && !user) router.push("/login");
  }, [ready, user, router]);

  if (!ready) return <div className="p-8">loading…</div>;
  if (!user) return null;

  return (
    <div>
      <div className="max-w-[1600px] mx-auto px-4 pt-4 flex items-center gap-2">
        <div className="glass rounded-full p-1 flex items-center gap-1 text-sm">
          <button className={`px-3 py-1.5 rounded-full ${view === "board" ? "" : "opacity-70"}`} style={view === "board" ? { background: "linear-gradient(135deg, var(--accent), var(--accent-2))" } : undefined} onClick={() => setView("board")}>🗂 Board</button>
          <button className={`px-3 py-1.5 rounded-full ${view === "calendar" ? "" : "opacity-70"}`} style={view === "calendar" ? { background: "linear-gradient(135deg, var(--accent), var(--accent-2))" } : undefined} onClick={() => setView("calendar")}>📅 Calendar</button>
        </div>
      </div>
      {view === "board" ? <KanbanBoard /> : <CalendarView />}
    </div>
  );
}
