"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { useStore } from "@/lib/store";
import { ALL_BADGES, levelFromXp } from "@/lib/badges";

export default function VibeCheck() {
  const { user, board } = useStore();
  const router = useRouter();
  const [ready, setReady] = useState(false);
  useEffect(() => { setReady(true); }, []);
  useEffect(() => { if (ready && !user) router.push("/login"); }, [ready, user, router]);

  const lv = user ? levelFromXp(user.xp) : null;
  const today = new Date().toISOString().slice(0, 10);

  const heatmap = useMemo(() => {
    if (!user) return [] as { date: string; count: number }[];
    const set = new Set(user.loginHistory || []);
    const cells: { date: string; count: number }[] = [];
    for (let i = 29; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const iso = d.toISOString().slice(0, 10);
      cells.push({ date: iso, count: set.has(iso) ? 1 : 0 });
    }
    return cells;
  }, [user]);

  const week = useMemo(() => {
    const days: { label: string; done: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const iso = d.toISOString().slice(0, 10);
      const done = board.cards.filter((c) => c.completed && c.completedAt && new Date(c.completedAt).toISOString().slice(0, 10) === iso).length;
      days.push({ label: d.toLocaleDateString(undefined, { weekday: "short" }), done });
    }
    return days;
  }, [board]);

  if (!ready || !user || !lv) return <div className="p-8">loading…</div>;

  const open = board.cards.filter((c) => !c.completed).length;
  const done = board.cards.filter((c) => c.completed).length;
  const overdue = board.cards.filter((c) => !c.completed && c.dueDate && c.dueDate < today).length;
  const maxWeek = Math.max(1, ...week.map((w) => w.done));

  const wrap = done >= 7
    ? "certified slay week 💅 keep the momentum, superstar."
    : done >= 3
      ? "solid rhythm — one more push and it's a wrap."
      : "warm-up week. tomorrow you cook. 🍳";

  const earned = new Set(user.badges.map((b) => b.id));

  return (
    <div className="max-w-[1200px] mx-auto px-4 py-6">
      <div className="flex items-center gap-3 mb-4">
        <h1 className="text-3xl font-black">Vibe check</h1>
        <Link href="/board" className="btn btn-ghost text-sm">← Back to board</Link>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        <div className="glass-2 rounded-3xl p-5">
          <div className="text-xs uppercase opacity-70 tracking-wider">Level</div>
          <div className="text-5xl font-black mt-2">{lv.level}</div>
          <div className="w-full h-2 rounded-full mt-3 overflow-hidden" style={{ background: "var(--surface-2)" }}>
            <div className="h-full" style={{ width: `${(lv.progress / lv.needed) * 100}%`, background: "linear-gradient(90deg, var(--accent), var(--accent-2))" }} />
          </div>
          <div className="text-xs opacity-70 mt-1">{lv.progress}/{lv.needed} XP — total {user.xp}</div>
        </div>

        <div className="glass-2 rounded-3xl p-5">
          <div className="text-xs uppercase opacity-70 tracking-wider">Streak</div>
          <div className="text-5xl font-black mt-2">🔥 {user.streak}</div>
          <div className="text-xs opacity-70 mt-2">Come back tomorrow to keep it alive.</div>
        </div>

        <div className="glass-2 rounded-3xl p-5">
          <div className="text-xs uppercase opacity-70 tracking-wider">Board health</div>
          <div className="mt-2 grid grid-cols-3 gap-2 text-center">
            <Stat label="open" value={open} />
            <Stat label="done" value={done} />
            <Stat label="overdue" value={overdue} />
          </div>
        </div>
      </div>

      <div className="mt-4 grid md:grid-cols-2 gap-4">
        <div className="glass-2 rounded-3xl p-5">
          <div className="font-bold mb-3">Last 30 days login</div>
          <div className="grid grid-cols-10 gap-1.5">
            {heatmap.map((c) => (
              <div key={c.date} title={c.date} className="aspect-square rounded" style={{
                background: c.count > 0 ? "linear-gradient(135deg, var(--accent), var(--accent-2))" : "var(--surface-2)",
                opacity: c.count > 0 ? 1 : 0.5,
              }} />
            ))}
          </div>
          <div className="text-xs opacity-70 mt-2">GitHub-style. Log in daily for +10 XP.</div>
        </div>

        <div className="glass-2 rounded-3xl p-5">
          <div className="font-bold mb-3">This week — completions</div>
          <div className="flex items-end gap-2 h-40">
            {week.map((d) => (
              <div key={d.label} className="flex-1 flex flex-col items-center gap-2">
                <div className="w-full rounded-t-lg transition-all" style={{ height: `${(d.done / maxWeek) * 100}%`, background: "linear-gradient(180deg, var(--accent-2), var(--accent))", minHeight: 4 }} />
                <div className="text-[10px] opacity-70">{d.label}</div>
                <div className="text-xs font-bold">{d.done}</div>
              </div>
            ))}
          </div>
          <div className="text-sm mt-3 opacity-90 italic">weekly wrap-up: {wrap}</div>
        </div>
      </div>

      <div className="mt-4 glass-2 rounded-3xl p-5">
        <div className="font-bold mb-3">Badges ({user.badges.length}/{ALL_BADGES.length})</div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
          {ALL_BADGES.map((b) => {
            const got = earned.has(b.id);
            return (
              <div key={b.id} className="glass rounded-2xl p-3 text-center relative" style={{ opacity: got ? 1 : 0.35 }}>
                <div className="text-3xl">{b.emoji}</div>
                <div className="font-semibold text-sm mt-1">{b.name}</div>
                <div className="text-[11px] opacity-70">{b.description}</div>
                {got && <div className="chip absolute top-2 right-2 !bg-emerald-500/25 !text-xs">✓</div>}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="glass rounded-xl p-2">
      <div className="text-lg font-bold">{value}</div>
      <div className="text-[10px] uppercase opacity-70">{label}</div>
    </div>
  );
}
