"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import type { Board, Card } from "@/lib/types";
import { Logo } from "@/components/TopBar";
import { use } from "react";

export default function SharePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const [board, setBoard] = useState<Board | null>(null);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(`slayte:public:${id}`);
      if (raw) setBoard(JSON.parse(raw) as Board);
      else setNotFound(true);
    } catch {
      setNotFound(true);
    }
  }, [id]);

  const cardsByCol = useMemo(() => {
    const map = new Map<string, Card[]>();
    if (!board) return map;
    for (const col of board.columns) map.set(col.id, []);
    for (const c of board.cards) map.get(c.columnId)?.push(c);
    for (const arr of map.values()) arr.sort((a, b) => a.order - b.order);
    return map;
  }, [board]);

  return (
    <main className="min-h-screen">
      <header className="glass-2 sticky top-0 z-40 px-4 py-3 flex items-center gap-3">
        <Link href="/" className="flex items-center gap-2">
          <Logo size={28} />
          <div className="font-black gradient-text">Slayte</div>
        </Link>
        <div className="chip">public board</div>
        <div className="flex-1" />
        <Link href="/board" className="btn btn-primary">Make your own →</Link>
      </header>

      {notFound && (
        <div className="max-w-lg mx-auto glass-2 rounded-3xl p-6 mt-16 text-center">
          <div className="text-4xl mb-2">👻</div>
          <div className="font-bold">Board not found</div>
          <div className="opacity-70 text-sm mt-1">Public sharing uses this browser&apos;s storage. Open the link on the device that shared it.</div>
        </div>
      )}

      {board && (
        <div className="max-w-[1400px] mx-auto px-4 py-4">
          <div className="text-2xl font-black mb-2">{board.name} <span className="chip">read only</span></div>
          <div className="flex gap-4 overflow-x-auto pb-6 scrollbar-slim">
            {board.columns.sort((a, b) => a.order - b.order).map((col) => (
              <div key={col.id} className="shrink-0 w-[320px] glass-2 rounded-3xl p-3">
                <div className="flex items-center gap-2 mb-2">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ background: col.color || "var(--accent)" }} />
                  <div className="font-bold">{col.title}</div>
                  <span className="chip !text-xs">{(cardsByCol.get(col.id) || []).length}</span>
                </div>
                <div className="flex flex-col gap-2">
                  {(cardsByCol.get(col.id) || []).map((c) => (
                    <div key={c.id} className={`glass rounded-2xl p-3 ${c.completed ? "opacity-60" : ""}`}>
                      <div className="flex items-start gap-2">
                        {c.coverEmoji && <div className="text-xl">{c.coverEmoji}</div>}
                        <div className="flex-1">
                          <div className={`font-semibold text-sm ${c.completed ? "line-through" : ""}`}>{c.title}</div>
                          {c.description && <div className="text-xs opacity-70 mt-1 line-clamp-2 whitespace-pre-wrap">{c.description}</div>}
                          <div className="flex flex-wrap gap-1 mt-2">
                            {c.dueDate && <span className="chip">📅 {c.dueDate.slice(5)}</span>}
                            {c.labels.slice(0, 3).map((l) => <span key={l} className="chip !bg-white/10">#{l}</span>)}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </main>
  );
}
