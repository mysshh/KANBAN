"use client";

import Link from "next/link";
import { useStore } from "@/lib/store";
import { Logo } from "@/components/TopBar";

export default function Home() {
  const { user } = useStore();

  return (
    <main className="relative min-h-screen">
      {/* floating decorations */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="orb w-[500px] h-[500px] -top-32 -left-32" style={{ background: "var(--accent)" }} />
        <div className="orb w-[600px] h-[600px] top-1/4 -right-40" style={{ background: "var(--accent-2)" }} />
        <div className="orb w-[420px] h-[420px] bottom-0 left-1/4" style={{ background: "var(--accent-3)" }} />
        <div className="absolute top-24 right-12 text-6xl animate-float-slow">🪐</div>
        <div className="absolute top-[38%] left-8 text-5xl animate-float-slow" style={{ animationDelay: "1.2s" }}>🚀</div>
        <div className="absolute bottom-24 right-16 text-6xl animate-float-slow" style={{ animationDelay: "2.4s" }}>🌙</div>
        <div className="absolute top-[60%] right-1/3 text-4xl animate-float-slow" style={{ animationDelay: ".8s" }}>✨</div>
      </div>

      <div className="max-w-[1200px] mx-auto px-4 py-8 relative">
        {/* Top glass nav */}
        <nav className="glass-2 rounded-full px-4 py-3 flex items-center gap-3">
          <div className="flex items-center gap-2">
            <Logo size={30} />
            <div className="font-black tracking-tight text-lg gradient-text">Slayte</div>
          </div>
          <div className="flex-1" />
          <Link href="/login" className="btn btn-ghost">Login</Link>
          <Link href="/login?signup=1" className="btn btn-primary">Get started</Link>
        </nav>

        {/* Hero card — big glass card inspired by the reference */}
        <section className="mt-8 glass-2 rounded-[36px] p-6 md:p-10 relative overflow-hidden">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <div className="text-[10px] tracking-[0.5em] uppercase opacity-70 mb-3">Kanban × Vibes × Gamified</div>
              <h1 className="text-6xl md:text-8xl font-black leading-[0.9]">
                <span className="gradient-text">SLAYTE</span>
              </h1>
              <div className="mt-3 italic text-2xl md:text-3xl opacity-90">
                the kanban that <span className="gradient-text">slaps.</span>
              </div>
              <p className="mt-5 opacity-80 max-w-md">
                Drag-drop tasks, level up your streaks, run Pomodoros, react with emojis, and vibe with lo-fi in the background. It&apos;s giving productivity but make it aesthetic.
              </p>
              <div className="mt-6 flex gap-2 flex-wrap">
                {user ? (
                  <Link href="/board" className="btn btn-primary">Enter your board →</Link>
                ) : (
                  <>
                    <Link href="/login" className="btn btn-primary">LOGIN</Link>
                    <Link href="/login?signup=1" className="btn">CREATE ACCOUNT</Link>
                  </>
                )}
              </div>

              {/* icon row (fixed: these are all Links now, so they actually work) */}
              <div className="mt-6 flex items-center gap-2">
                <IconLink href="/" label="Home" emoji="🏠" />
                <IconLink href="/board" label="Board" emoji="🗂️" />
                <IconLink href="/vibe-check" label="Vibe check" emoji="📈" />
                <IconLink href="/login" label="Account" emoji="👤" />
              </div>
            </div>

            <div className="relative">
              <div className="glass rounded-3xl p-5">
                <div className="text-xs opacity-70">SLAYTE IS…</div>
                <div className="mt-2 font-bold text-lg">A cozy little space to plan chaos.</div>
                <p className="opacity-80 text-sm mt-2">
                  Board + calendar + focus mode + AI + gamification — all local, all yours, no login server, no cap.
                </p>
                <div className="grid grid-cols-2 gap-2 mt-4">
                  {[
                    ["🎯","Focus mode"], ["🏆","Badges + XP"], ["🎨","7 themes"], ["🎧","Lo-fi player"],
                    ["🔁","Recurring cards"], ["🔗","Public sharing"], ["📋","Templates"], ["✨","AI bestie"],
                  ].map(([e,l]) => (
                    <div key={l} className="glass rounded-xl px-3 py-2 text-sm flex items-center gap-2">
                      <span>{e}</span><span className="opacity-80">{l}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="absolute -top-6 -right-4 text-6xl md:text-7xl animate-float-slow">🧑‍🚀</div>
            </div>
          </div>
        </section>

        {/* Two chat-like glass cards */}
        <section className="mt-6 glass-2 rounded-[32px] p-5 md:p-8 relative">
          <div className="text-center text-xs tracking-[0.4em] uppercase opacity-70 mb-4">A quick tour of the vibes</div>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="glass rounded-3xl p-5">
              <div className="text-3xl mb-2">🪐</div>
              <p className="text-sm opacity-90">Slayte is basically Trello&apos;s aesthetic cousin. Drag cards, set WIP limits so you don&apos;t over-commit, and track subtasks with a lil progress bar. Persistence lives in your browser via localStorage — refresh, come back tomorrow, your board is there.</p>
              <Link href="/board" className="btn btn-ghost mt-3 text-sm">→ Try the board</Link>
            </div>
            <div className="glass rounded-3xl p-5 relative">
              <div className="text-3xl mb-2">🎯</div>
              <p className="text-sm opacity-90">Level up with XP for creating, completing and logging in daily. Unlock 12 badges. Ambient music, Pomodoro focus mode, and a Vibe Check dashboard with streak heatmap — all included.</p>
              <Link href="/vibe-check" className="btn btn-ghost mt-3 text-sm">→ See your stats</Link>
              <div className="absolute -top-6 right-4 text-5xl animate-float-slow">🚀</div>
            </div>
          </div>
        </section>

        {/* Feature tiles */}
        <section className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { emoji: "🖱️", title: "Drag & drop", body: "Native, no jank." },
            { emoji: "📅", title: "Calendar view", body: "Toggle board ⇄ month." },
            { emoji: "🧠", title: "AI bestie", body: "Suggests next steps." },
            { emoji: "🏅", title: "12 badges", body: "Chase the streak." },
          ].map((f) => (
            <div key={f.title} className="glass-2 rounded-2xl p-4">
              <div className="text-3xl">{f.emoji}</div>
              <div className="font-bold mt-1">{f.title}</div>
              <div className="text-sm opacity-70">{f.body}</div>
            </div>
          ))}
        </section>

        <footer className="mt-10 mb-6 text-center text-xs opacity-60 tracking-[0.3em] uppercase">
          crafted with 💜 · Slayte {new Date().getFullYear()}
        </footer>
      </div>
    </main>
  );
}

function IconLink({ href, label, emoji }: { href: string; label: string; emoji: string }) {
  return (
    <Link href={href} title={label} className="glass rounded-xl w-11 h-11 grid place-items-center hover:-translate-y-0.5 transition">
      <span className="text-lg">{emoji}</span>
    </Link>
  );
}
