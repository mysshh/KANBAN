"use client";

import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import type { Board, Card, Column, Subtask, Toast, User, Recurring } from "./types";
import { checkBadges, levelFromXp } from "./badges";

const LS_USER = "slayte:user";
const LS_BOARD = "slayte:board";
const LS_THEMES = "slayte:themesUsed";
const LS_PUBLIC = (id: string) => `slayte:public:${id}`;

function uid(prefix = "id") {
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}${Date.now().toString(36).slice(-4)}`;
}

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

function daysBetween(a: string, b: string) {
  const da = new Date(a + "T00:00:00Z").getTime();
  const db = new Date(b + "T00:00:00Z").getTime();
  return Math.round((db - da) / 86400000);
}

function defaultBoard(): Board {
  const now = Date.now();
  const cols: Column[] = [
    { id: "col_todo", title: "To do", order: 0, color: "#a78bfa" },
    { id: "col_doing", title: "In progress", order: 1, color: "#f472b6", wipLimit: 3 },
    { id: "col_review", title: "Review", order: 2, color: "#fbbf24", wipLimit: 2 },
    { id: "col_done", title: "Done ✨", order: 3, color: "#34d399" },
  ];
  const seed: Card[] = [
    baseCard({ columnId: "col_todo", title: "Welcome to Slayte 🫶", description: "Double-click a card title to edit inline. Drag cards between columns to slay.", coverEmoji: "🫶", order: 0, createdAt: now }),
    baseCard({ columnId: "col_todo", title: "Try Focus Mode 🎯", description: "Hit the target icon in the top bar for a Pomodoro session.", coverEmoji: "🎯", order: 1, createdAt: now + 1 }),
    baseCard({ columnId: "col_doing", title: "Shipping the vibes", description: "This card is 'in progress'. Move me to Done when you're feeling it.", coverEmoji: "🚀", order: 0, createdAt: now + 2 }),
    baseCard({ columnId: "col_done", title: "Set up the board", description: "Nice, you already did something 💅", coverEmoji: "✅", order: 0, createdAt: now + 3, completed: true, completedAt: now + 3 }),
  ];
  return { id: "main", name: "My board", columns: cols, cards: seed, isPublic: false, shareId: uid("sh") };
}

function baseCard(partial: Partial<Card> & Pick<Card, "columnId" | "title" | "order" | "createdAt">): Card {
  return {
    id: uid("c"),
    labels: [],
    completed: false,
    subtasks: [],
    blockedBy: [],
    reactions: [],
    timeEntries: [],
    activeTimerStart: null,
    recurring: null,
    ...partial,
  } as Card;
}

function loadUser(): User | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(LS_USER);
    if (!raw) return null;
    return JSON.parse(raw) as User;
  } catch {
    return null;
  }
}
function loadBoard(): Board {
  if (typeof window === "undefined") return defaultBoard();
  try {
    const raw = localStorage.getItem(LS_BOARD);
    if (!raw) return defaultBoard();
    const b = JSON.parse(raw) as Board;
    // hydrate legacy fields
    b.cards = b.cards.map((c) => ({
      ...c,
      subtasks: c.subtasks || [],
      blockedBy: c.blockedBy || [],
      reactions: c.reactions || [],
      timeEntries: c.timeEntries || [],
      activeTimerStart: c.activeTimerStart ?? null,
      recurring: c.recurring ?? null,
      labels: c.labels || [],
      completed: !!c.completed,
    }));
    if (!b.shareId) b.shareId = uid("sh");
    if (typeof b.isPublic !== "boolean") b.isPublic = false;
    return b;
  } catch {
    return defaultBoard();
  }
}

type Ctx = {
  user: User | null;
  board: Board;
  toasts: Toast[];
  setUser: (u: User | null) => void;
  login: (username: string) => void;
  logout: () => void;
  setTheme: (t: string) => void;

  addColumn: (title: string) => void;
  renameColumn: (id: string, title: string) => void;
  removeColumn: (id: string) => void;
  setWipLimit: (id: string, limit?: number) => void;

  addCard: (columnId: string, patch: Partial<Card>) => Card | null;
  updateCard: (id: string, patch: Partial<Card>) => void;
  removeCard: (id: string) => void;
  moveCard: (cardId: string, toColumnId: string, toIndex: number) => void;
  toggleComplete: (id: string) => void;

  addSubtask: (cardId: string, title: string) => void;
  toggleSubtask: (cardId: string, subId: string) => void;
  removeSubtask: (cardId: string, subId: string) => void;

  startTimer: (cardId: string) => void;
  stopTimer: (cardId: string) => void;

  toggleReaction: (cardId: string, emoji: string) => void;

  setRecurring: (cardId: string, r: Recurring) => void;
  spawnRecurringIfDue: () => void;

  togglePublic: () => void;

  pushToast: (t: Omit<Toast, "id">) => void;
  dismissToast: (id: string) => void;

  addXp: (amount: number, reason?: string) => void;
  bumpStat: (key: "cardsCreated" | "cardsCompleted" | "focusSessions", by?: number) => void;
  recomputeBadges: () => void;
};

const StoreCtx = createContext<Ctx | null>(null);

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [user, setUserState] = useState<User | null>(null);
  const [board, setBoard] = useState<Board>(() => defaultBoard());
  const [toasts, setToasts] = useState<Toast[]>([]);
  const themesUsedRef = useRef<Set<string>>(new Set());
  const [hydrated, setHydrated] = useState(false);

  // hydrate from localStorage on mount
  useEffect(() => {
    setUserState(loadUser());
    setBoard(loadBoard());
    try {
      const t = localStorage.getItem(LS_THEMES);
      themesUsedRef.current = new Set(t ? JSON.parse(t) : []);
    } catch {}
    setHydrated(true);
  }, []);

  // persist
  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem(LS_BOARD, JSON.stringify(board));
    if (board.isPublic) localStorage.setItem(LS_PUBLIC(board.shareId), JSON.stringify(board));
  }, [board, hydrated]);
  useEffect(() => {
    if (!hydrated) return;
    if (user) localStorage.setItem(LS_USER, JSON.stringify(user));
    else localStorage.removeItem(LS_USER);
  }, [user, hydrated]);

  // apply theme
  useEffect(() => {
    const t = user?.theme || "default";
    if (typeof document === "undefined") return;
    if (t === "default") document.documentElement.removeAttribute("data-theme");
    else document.documentElement.setAttribute("data-theme", t);
  }, [user?.theme]);

  const pushToast = useCallback((t: Omit<Toast, "id">) => {
    const id = uid("t");
    setToasts((prev) => [...prev, { ...t, id }]);
    setTimeout(() => setToasts((prev) => prev.filter((x) => x.id !== id)), 4000);
  }, []);
  const dismissToast = useCallback((id: string) => setToasts((prev) => prev.filter((x) => x.id !== id)), []);

  const setUser = useCallback((u: User | null) => setUserState(u), []);

  const recomputeBadges = useCallback(() => {
    setUserState((u) => {
      if (!u) return u;
      const newly = checkBadges(u, board, { themesUsed: themesUsedRef.current });
      if (newly.length === 0) return u;
      newly.forEach((b) => pushToast({ kind: "badge", title: `Badge unlocked: ${b.emoji} ${b.name}`, body: b.description }));
      return { ...u, badges: [...u.badges, ...newly] };
    });
  }, [board, pushToast]);

  const addXp = useCallback((amount: number, reason?: string) => {
    setUserState((u) => {
      if (!u) return u;
      const before = levelFromXp(u.xp).level;
      const next = { ...u, xp: u.xp + amount };
      const after = levelFromXp(next.xp).level;
      pushToast({ kind: "xp", title: `+${amount} XP`, body: reason });
      if (after > before) {
        next.level = after;
        setTimeout(() => pushToast({ kind: "level", title: `🎉 Level up! You're level ${after}`, body: "Keep slaying." }), 400);
      }
      return next;
    });
  }, [pushToast]);

  const bumpStat = useCallback((key: "cardsCreated" | "cardsCompleted" | "focusSessions", by = 1) => {
    setUserState((u) => (u ? { ...u, [key]: (u[key] || 0) + by } : u));
  }, []);

  // trigger badge check whenever user stats change
  useEffect(() => {
    if (!hydrated || !user) return;
    const t = setTimeout(recomputeBadges, 100);
    return () => clearTimeout(t);
  }, [user?.cardsCreated, user?.cardsCompleted, user?.focusSessions, user?.streak, board.cards.length, hydrated, recomputeBadges, user]);

  const login = useCallback((username: string) => {
    const existing = loadUser();
    const today = todayStr();
    let u: User;
    if (existing && existing.username.toLowerCase() === username.toLowerCase()) {
      u = existing;
    } else {
      u = {
        username,
        createdAt: Date.now(),
        xp: 0, level: 1, streak: 0,
        lastLoginDate: "",
        loginHistory: [],
        cardsCreated: 0, cardsCompleted: 0, focusSessions: 0,
        badges: [], theme: "default",
      };
    }
    // streak logic + daily login xp
    const gap = u.lastLoginDate ? daysBetween(u.lastLoginDate, today) : -1;
    let bonus = 0;
    let streakToast = false;
    if (u.lastLoginDate !== today) {
      if (gap === 1) u.streak += 1;
      else if (gap === 0) { /* same day */ }
      else u.streak = 1;
      u.lastLoginDate = today;
      if (!u.loginHistory.includes(today)) u.loginHistory = [...u.loginHistory, today];
      bonus = 10;
      streakToast = true;
    }
    setUserState(u);
    if (bonus > 0) setTimeout(() => addXp(bonus, "Daily login"), 300);
    if (streakToast) setTimeout(() => pushToast({ kind: "info", title: `🔥 Streak: ${u.streak} day${u.streak === 1 ? "" : "s"}` }), 700);
  }, [addXp, pushToast]);

  const logout = useCallback(() => setUserState(null), []);

  const setTheme = useCallback((t: string) => {
    setUserState((u) => (u ? { ...u, theme: t } : u));
    themesUsedRef.current.add(t);
    try { localStorage.setItem(LS_THEMES, JSON.stringify(Array.from(themesUsedRef.current))); } catch {}
  }, []);

  // Column ops
  const addColumn = (title: string) => setBoard((b) => ({ ...b, columns: [...b.columns, { id: uid("col"), title, order: b.columns.length, color: "#a78bfa" }] }));
  const renameColumn = (id: string, title: string) => setBoard((b) => ({ ...b, columns: b.columns.map((c) => (c.id === id ? { ...c, title } : c)) }));
  const removeColumn = (id: string) => setBoard((b) => ({ ...b, columns: b.columns.filter((c) => c.id !== id), cards: b.cards.filter((c) => c.columnId !== id) }));
  const setWipLimit = (id: string, limit?: number) => setBoard((b) => ({ ...b, columns: b.columns.map((c) => (c.id === id ? { ...c, wipLimit: limit } : c)) }));

  // Card ops
  const addCard = (columnId: string, patch: Partial<Card>) => {
    let created: Card | null = null;
    setBoard((b) => {
      const order = b.cards.filter((c) => c.columnId === columnId).length;
      const card = baseCard({ columnId, title: patch.title || "New task", order, createdAt: Date.now(), ...patch });
      created = card;
      return { ...b, cards: [...b.cards, card] };
    });
    bumpStat("cardsCreated");
    setTimeout(() => addXp(5, "Card created"), 50);
    return created;
  };

  const updateCard = (id: string, patch: Partial<Card>) => setBoard((b) => ({ ...b, cards: b.cards.map((c) => (c.id === id ? { ...c, ...patch } : c)) }));
  const removeCard = (id: string) => setBoard((b) => ({ ...b, cards: b.cards.filter((c) => c.id !== id).map((c) => ({ ...c, blockedBy: c.blockedBy.filter((x) => x !== id) })) }));

  const moveCard = (cardId: string, toColumnId: string, toIndex: number) => {
    setBoard((b) => {
      const card = b.cards.find((c) => c.id === cardId);
      if (!card) return b;
      const fromColumn = card.columnId;
      // remove from current col ordering
      const others = b.cards.filter((c) => c.id !== cardId);
      const destCards = others.filter((c) => c.columnId === toColumnId).sort((a, b) => a.order - b.order);
      const newCard: Card = { ...card, columnId: toColumnId };
      const clampedIndex = Math.max(0, Math.min(toIndex, destCards.length));
      destCards.splice(clampedIndex, 0, newCard);
      const reindexedDest = destCards.map((c, i) => ({ ...c, order: i }));
      const reindexedSource = fromColumn !== toColumnId
        ? others.filter((c) => c.columnId === fromColumn).sort((a, b) => a.order - b.order).map((c, i) => ({ ...c, order: i }))
        : [];
      const untouched = others.filter((c) => c.columnId !== toColumnId && c.columnId !== fromColumn);
      return { ...b, cards: [...untouched, ...reindexedDest, ...reindexedSource] };
    });
  };

  const toggleComplete = (id: string) => {
    setBoard((b) => {
      const c = b.cards.find((x) => x.id === id);
      if (!c) return b;
      const willComplete = !c.completed;
      return {
        ...b,
        cards: b.cards.map((x) => (x.id === id ? { ...x, completed: willComplete, completedAt: willComplete ? Date.now() : undefined } : x)),
      };
    });
    const c = board.cards.find((x) => x.id === id);
    if (c && !c.completed) {
      bumpStat("cardsCompleted");
      setTimeout(() => addXp(20, "Task completed"), 60);
    }
  };

  const addSubtask = (cardId: string, title: string) => updateSubtasks(cardId, (s) => [...s, { id: uid("s"), title, done: false }]);
  const toggleSubtask = (cardId: string, subId: string) => updateSubtasks(cardId, (s) => s.map((x) => (x.id === subId ? { ...x, done: !x.done } : x)));
  const removeSubtask = (cardId: string, subId: string) => updateSubtasks(cardId, (s) => s.filter((x) => x.id !== subId));

  function updateSubtasks(cardId: string, fn: (s: Subtask[]) => Subtask[]) {
    setBoard((b) => ({ ...b, cards: b.cards.map((c) => (c.id === cardId ? { ...c, subtasks: fn(c.subtasks) } : c)) }));
  }

  const startTimer = (cardId: string) => setBoard((b) => ({ ...b, cards: b.cards.map((c) => (c.id === cardId ? { ...c, activeTimerStart: Date.now() } : c)) }));
  const stopTimer = (cardId: string) => setBoard((b) => ({
    ...b,
    cards: b.cards.map((c) => {
      if (c.id !== cardId || !c.activeTimerStart) return c;
      return { ...c, activeTimerStart: null, timeEntries: [...c.timeEntries, { start: c.activeTimerStart, end: Date.now() }] };
    }),
  }));

  const toggleReaction = (cardId: string, emoji: string) => setBoard((b) => ({
    ...b,
    cards: b.cards.map((c) => {
      if (c.id !== cardId) return c;
      const u = user?.username || "you";
      const existing = c.reactions.find((r) => r.emoji === emoji);
      let reactions;
      if (!existing) reactions = [...c.reactions, { emoji, users: [u] }];
      else if (existing.users.includes(u)) {
        const users = existing.users.filter((x) => x !== u);
        reactions = users.length === 0 ? c.reactions.filter((r) => r.emoji !== emoji) : c.reactions.map((r) => (r.emoji === emoji ? { ...r, users } : r));
      } else {
        reactions = c.reactions.map((r) => (r.emoji === emoji ? { ...r, users: [...r.users, u] } : r));
      }
      return { ...c, reactions };
    }),
  }));

  const setRecurring = (cardId: string, r: Recurring) => updateCard(cardId, { recurring: r });

  const spawnRecurringIfDue = useCallback(() => {
    setBoard((b) => {
      const now = Date.now();
      const additions: Card[] = [];
      const updated = b.cards.map((c) => {
        if (!c.recurring) return c;
        const gapMs = c.recurring.pattern === "daily" ? 86400000 : c.recurring.pattern === "weekly" ? 7 * 86400000 : 30 * 86400000;
        if (now - c.recurring.lastSpawnedAt >= gapMs) {
          const orderInCol = b.cards.filter((x) => x.columnId === c.columnId).length + additions.filter((x) => x.columnId === c.columnId).length;
          additions.push(baseCard({
            columnId: c.columnId, title: c.title, description: c.description, priority: c.priority, labels: [...c.labels],
            coverEmoji: c.coverEmoji, order: orderInCol, createdAt: now, subtasks: c.subtasks.map((s) => ({ ...s, id: uid("s"), done: false })),
          }));
          return { ...c, recurring: { ...c.recurring, lastSpawnedAt: now } };
        }
        return c;
      });
      return { ...b, cards: [...updated, ...additions] };
    });
  }, []);

  const togglePublic = () => setBoard((b) => {
    const next = { ...b, isPublic: !b.isPublic };
    if (!next.isPublic) {
      try { localStorage.removeItem(LS_PUBLIC(b.shareId)); } catch {}
    }
    return next;
  });

  useEffect(() => {
    spawnRecurringIfDue();
    const t = setInterval(spawnRecurringIfDue, 60_000);
    return () => clearInterval(t);
  }, [spawnRecurringIfDue]);

  const value: Ctx = useMemo(() => ({
    user, board, toasts, setUser, login, logout, setTheme,
    addColumn, renameColumn, removeColumn, setWipLimit,
    addCard, updateCard, removeCard, moveCard, toggleComplete,
    addSubtask, toggleSubtask, removeSubtask,
    startTimer, stopTimer, toggleReaction, setRecurring, spawnRecurringIfDue,
    togglePublic, pushToast, dismissToast, addXp, bumpStat, recomputeBadges,
  }), [user, board, toasts]); // eslint-disable-line react-hooks/exhaustive-deps

  return <StoreCtx.Provider value={value}>{children}</StoreCtx.Provider>;
}

export function useStore() {
  const ctx = useContext(StoreCtx);
  if (!ctx) throw new Error("useStore must be used inside StoreProvider");
  return ctx;
}
