export type Priority = "low" | "med" | "high";

export type Subtask = { id: string; title: string; done: boolean };

export type Reaction = { emoji: string; users: string[] };

export type TimeEntry = { start: number; end: number | null };

export type Recurring = { pattern: "daily" | "weekly" | "monthly"; lastSpawnedAt: number } | null;

export type Card = {
  id: string;
  columnId: string;
  title: string;
  description?: string;
  priority?: Priority;
  labels: string[];
  dueDate?: string; // ISO date
  createdAt: number;
  completed: boolean;
  completedAt?: number;
  order: number;
  coverEmoji?: string;
  subtasks: Subtask[];
  blockedBy: string[]; // card ids
  reactions: Reaction[];
  timeEntries: TimeEntry[];
  activeTimerStart?: number | null;
  recurring: Recurring;
};

export type Column = {
  id: string;
  title: string;
  order: number;
  wipLimit?: number;
  color?: string;
};

export type Board = {
  id: string;
  name: string;
  columns: Column[];
  cards: Card[];
  isPublic: boolean;
  shareId: string;
};

export type Badge = {
  id: string;
  name: string;
  emoji: string;
  description: string;
  earnedAt?: number;
};

export type User = {
  username: string;
  createdAt: number;
  xp: number;
  level: number;
  streak: number;
  lastLoginDate: string; // YYYY-MM-DD
  loginHistory: string[]; // YYYY-MM-DD
  cardsCreated: number;
  cardsCompleted: number;
  focusSessions: number;
  badges: Badge[];
  theme: string;
  ambientTrack?: string;
};

export type Toast = {
  id: string;
  title: string;
  body?: string;
  kind: "xp" | "level" | "badge" | "info" | "error";
};

export type CardTemplate = {
  id: string;
  name: string;
  emoji: string;
  card: Partial<Card>;
};
