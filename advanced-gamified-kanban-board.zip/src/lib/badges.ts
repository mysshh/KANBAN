import type { Badge, User, Board } from "./types";

export const ALL_BADGES: Badge[] = [
  { id: "first-blood", name: "First Blood", emoji: "🩸", description: "Create your first card" },
  { id: "on-fire", name: "On Fire", emoji: "🔥", description: "Complete 3 cards in one day" },
  { id: "week-warrior", name: "Week Warrior", emoji: "⚔️", description: "7-day streak" },
  { id: "month-mode", name: "Month Mode", emoji: "🗓️", description: "30-day streak" },
  { id: "completionist", name: "Completionist", emoji: "🏆", description: "Complete 50 cards" },
  { id: "century", name: "Century Club", emoji: "💯", description: "Complete 100 cards" },
  { id: "collector", name: "Collector", emoji: "🃏", description: "Create 25 cards" },
  { id: "focused", name: "Locked In", emoji: "🎯", description: "Finish 5 focus sessions" },
  { id: "night-owl", name: "Night Owl", emoji: "🦉", description: "Create a card after midnight" },
  { id: "early-bird", name: "Early Bird", emoji: "🐦", description: "Create a card before 7am" },
  { id: "planner", name: "Grand Planner", emoji: "🗺️", description: "Use 3 columns actively" },
  { id: "aesthete", name: "Aesthete", emoji: "🎨", description: "Try 3 different themes" },
];

export function checkBadges(user: User, board: Board | null, ctx: { themesUsed?: Set<string> } = {}): Badge[] {
  const owned = new Set(user.badges.map((b) => b.id));
  const newly: Badge[] = [];
  const now = Date.now();
  const add = (id: string) => {
    if (owned.has(id)) return;
    const b = ALL_BADGES.find((x) => x.id === id);
    if (b) newly.push({ ...b, earnedAt: now });
  };

  if (user.cardsCreated >= 1) add("first-blood");
  if (user.cardsCreated >= 25) add("collector");
  if (user.cardsCompleted >= 50) add("completionist");
  if (user.cardsCompleted >= 100) add("century");
  if (user.streak >= 7) add("week-warrior");
  if (user.streak >= 30) add("month-mode");
  if (user.focusSessions >= 5) add("focused");

  const hour = new Date().getHours();
  if (hour < 5) add("night-owl");
  if (hour >= 4 && hour < 7) add("early-bird");

  if (board) {
    const active = new Set(board.cards.map((c) => c.columnId));
    if (active.size >= 3) add("planner");

    const today = new Date().toISOString().slice(0, 10);
    const completedToday = board.cards.filter(
      (c) => c.completed && c.completedAt && new Date(c.completedAt).toISOString().slice(0, 10) === today
    ).length;
    if (completedToday >= 3) add("on-fire");
  }

  if (ctx.themesUsed && ctx.themesUsed.size >= 3) add("aesthete");

  return newly;
}

export function xpForLevel(level: number) {
  return 100 + level * 50;
}
export function levelFromXp(xp: number): { level: number; progress: number; needed: number } {
  let level = 1;
  let remaining = xp;
  while (remaining >= xpForLevel(level)) {
    remaining -= xpForLevel(level);
    level += 1;
  }
  return { level, progress: remaining, needed: xpForLevel(level) };
}
