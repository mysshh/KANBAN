import type { CardTemplate } from "./types";

export const TEMPLATES: CardTemplate[] = [
  {
    id: "bug",
    name: "Bug Report",
    emoji: "🐛",
    card: {
      title: "Bug: ",
      description:
        "**Steps to reproduce**\n1. \n2. \n3. \n\n**Expected**\n\n**Actual**\n\n**Environment**\n- Browser:\n- OS:",
      labels: ["bug"],
      priority: "high",
      coverEmoji: "🐛",
      subtasks: [
        { id: "s1", title: "Reproduce locally", done: false },
        { id: "s2", title: "Write test case", done: false },
        { id: "s3", title: "Ship fix", done: false },
      ],
    },
  },
  {
    id: "feat",
    name: "Feature Request",
    emoji: "✨",
    card: {
      title: "Feature: ",
      description: "**Problem**\n\n**Proposal**\n\n**Success metrics**",
      labels: ["feature"],
      priority: "med",
      coverEmoji: "✨",
      subtasks: [
        { id: "s1", title: "Draft spec", done: false },
        { id: "s2", title: "Design review", done: false },
        { id: "s3", title: "Implement", done: false },
        { id: "s4", title: "QA", done: false },
      ],
    },
  },
  {
    id: "content",
    name: "Content Brief",
    emoji: "📝",
    card: {
      title: "Brief: ",
      description: "**Audience**\n\n**Angle**\n\n**Deliverables**\n\n**Distribution**",
      labels: ["content"],
      coverEmoji: "📝",
      subtasks: [
        { id: "s1", title: "Outline", done: false },
        { id: "s2", title: "Draft", done: false },
        { id: "s3", title: "Edit", done: false },
        { id: "s4", title: "Publish", done: false },
      ],
    },
  },
  {
    id: "meeting",
    name: "Meeting Notes",
    emoji: "🗒️",
    card: {
      title: "Meeting: ",
      description: "**Attendees**\n\n**Agenda**\n\n**Decisions**\n\n**Action items**",
      labels: ["meeting"],
      coverEmoji: "🗒️",
      subtasks: [],
    },
  },
  {
    id: "sprint",
    name: "Sprint Goal",
    emoji: "🎯",
    card: {
      title: "Sprint goal: ",
      description: "**Outcome**\n\n**Key results**\n\n**Risks**",
      labels: ["sprint"],
      priority: "high",
      coverEmoji: "🎯",
      subtasks: [
        { id: "s1", title: "Kickoff", done: false },
        { id: "s2", title: "Mid-sprint check-in", done: false },
        { id: "s3", title: "Retro", done: false },
      ],
    },
  },
];
